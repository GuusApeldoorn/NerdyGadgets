/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectkbsd;

/**
 *
 * @author Marc
 */
public class Databaseloadbalancer extends Component {
    
    public Databaseloadbalancer(double availability, int price ) {
        super("Databaseloadbalancer", availability, price);
    }
}
